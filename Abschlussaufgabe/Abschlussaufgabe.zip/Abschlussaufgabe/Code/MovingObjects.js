var L12_Canvas;
(function (L12_Canvas) {
    class MovingObjects {
        constructor(_x, _y) {
            this.x = _x;
            this.y = _y;
        }
        update() {
            this.move();
            this.draw();
        }
        move() {
            ;
        }
        draw() {
            ;
        }
    }
    L12_Canvas.MovingObjects = MovingObjects;
})(L12_Canvas || (L12_Canvas = {}));
//# sourceMappingURL=MovingObjects.js.map